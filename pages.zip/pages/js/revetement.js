document.title = "Revetements";
document.getElementById('TitrePage').innerHTML = "Revetements";
var DG_QUERY_TAG = "GetRevetement";
var DG_TABLE_NAME = "Revetement";
var DG_Definition =
 [
    { "ColName": "IdRevetement", "Width": 50, "Visible": true, "ColumnHeader": "IdRevetement" },
    { "ColName": "Type", "Width": 150, "Visible": true, "ColumnHeader": "Type" },
    { "ColName": "NomCom", "Width": 200, "Visible": true, "ColumnHeader": "NomCom" },
    { "ColName": "Fournis", "Width": 200, "Visible": true, "ColumnHeader": "Fournis" },
    { "ColName": "Compochim", "Width": 200, "Visible": true, "ColumnHeader": "Compochim" },
    { "ColName": "Epaisseur", "Width": 200, "Visible": true, "ColumnHeader": "Epaisseur" },
    { "ColName": "Durete", "Width": 200, "Visible": true, "ColumnHeader": "Durete" },
    { "ColName": "UnitDurete", "Width": 200, "Visible": true, "ColumnHeader": "UnitDurete" },
    { "ColName": "CoeffFrottement", "Width": 200, "Visible": true, "ColumnHeader": "CoeffFrottement" },
    // { "ColName": "Propriete", "Width": 200, "Visible": true, "ColumnHeader": "Propriete" },
    //{ "ColName": "Observation", "Width": 200, "Visible": true, "ColumnHeader": "Observation" },
    //{ "ColName": "Procedure", "Width": 200, "Visible": true, "ColumnHeader": "Procedure" },
];


$("#ColOpt").load("form/ColOpt.html");
$("#formModal").load("form/revetementModal.html");