/*https://cssreference.io/flexbox/   */
/*-----   todo 
gestion des cliques
-----*/
function splitValue(value, index) {
    return value.substring(0, index);
};

$(function() {
   $('a.link').click(function() {
       $('a.link').removeClass('active');
       $(this).addClass('active');
       var ah1=$(this).attr('href');
       var ah2=ah1.split("#")[1];
       for (i = 0; i < 10; i++) {
         try {
          var text=splitValue(ah2,8)+i;
           document.getElementById(text).className = "panel-collapse collapse";
          }
         catch (e) {
           
         }
        } ;
       document.getElementById(ah2).className = "panel-collapse collapse in"; 
   });

});

/*
$("p").css("display", "block"); */