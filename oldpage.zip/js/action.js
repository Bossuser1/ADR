﻿
"cette partie du code sert a gerer la section de display de option de sorte a pouvoir caché le tableau"
"une grande partie est gerer au niveau du fichier DG.js"
"mais pour la visibilité des feuilles on passera un css la dessus egalement"

/*
var compteurclik = 2;
function showAlert(compteurclik) {
    compteurclik =compteurclik+1;
    var cache = document.getElementById("bar");
    if (compteurclik % 2 === 0) {
        cache.style.visibility ='hidden';
    } else {
        cache.style.visibility = 'visible';
    }
    alert(compteurclik);
    return compteurclik;
}


var poptionshow = document.getElementById("ModBtnOpenColOption");
var valideop = document.getElementById("ModalBtnOK_ColOpt");
poptionshow.onclick = showAlert(compteurclik);
valideop.onclick = showAlert(compteurclik);

$(document).ready(function(){
 
    if ($("#ColOpt").size()>0){
            if (document.createStyleSheet){
                document.createStyleSheet('css/option.css');
    }
            else {
                $("head").append($("<link rel='stylesheet' href='css/option.css' type='text/css' media='screen' />"));
    }
        }
});

*/
bt1 = document.getElementById("ModalBtnClose");
bt1.click();