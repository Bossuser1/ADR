﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Description résumée de DBAWebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// Pour autoriser l'appel de ce service Web depuis un script à l'aide d'ASP.NET AJAX, supprimez les marques de commentaire de la ligne suivante. 
 [System.Web.Script.Services.ScriptService]
public class DBAWebService : System.Web.Services.WebService
{

    public DBAWebService()
    {
        //Supprimez les marques de commentaire dans la ligne suivante si vous utilisez des composants conçus 
        //InitializeComponent(); 
    }

    [WebMethod]
    public int ExecQuery(string tableName, string queryType, List<Data> listparam)
    {
        int result = -1;
        string cstag = "cs"+tableName;
        cstag = ConfigurationManager.AppSettings.Get(cstag);
        string cs = ConfigurationManager.ConnectionStrings[cstag].ConnectionString;
    
        TabInfo tab = new TabInfo(tableName, cs);
        SqlCommand cmd = null;// new SqlCommand();

        if (queryType.ToLower() == "insert") cmd = tab.Insert(ref listparam);
        if (queryType.ToLower() == "update") cmd = tab.Update(ref listparam);
        if (queryType.ToLower() == "delete") cmd = tab.Delete(ref listparam);

        using (SqlConnection con = new SqlConnection(cs))
        {
            cmd.Connection = con;
            SqlTransaction transc_ = null;//TRANSACTION  
            try
            {
                con.Open();
                //START TRANSACTION - Critical Zone write to database TRANSACTION
                transc_ = con.BeginTransaction(Math.Round(DateTime.UtcNow.Subtract(new DateTime(2014, 1, 1, 0, 0, 0)).TotalSeconds, 0).ToString());//TRANSACTION
                if (transc_ == null) { throw new Exception("transc_ == null;"); } //TRANSACTION
                cmd.Transaction = transc_; //TRANSACTION
                result = cmd.ExecuteNonQuery();
                transc_.Commit();//TRANSACTION
                //END TRANSACTION - Critical Zone write to database TRANSACTION
                cmd.Dispose();
            }
            catch (Exception err)
            {
                Utils.ExcepMsg.TrcMsgToFile("DBA.ExecuteQuery: " + err.Message.ToUpper() + " query:" ,@"D:\test.log");
                try {  transc_.Rollback(); //TRANSACTION
                }
                catch (Exception err2){
                    Utils.ExcepMsg.TrcExcep("Rollback Exception Type: {0}; " + err2.GetType() + " query: " , @"D:\test.log");
                    Utils.ExcepMsg.TrcExcep("Message: {0}; " + err2.Message + " query: " , @"D:\test.log");
                }
            }
        }
        return result;
    }


 

   
    //-----------------------------------------------------------
    [WebMethod]
    public TabInfo GetTabInfoByName(string tableName)
    {
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + tableName);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
        TabInfo tab = new TabInfo(tableName, cs);
        return tab;
    }
    //-----------------------------------------------------------


    /*   [WebMethod]
       public List<DataFB> GetData(string tag)
       {
           string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
           string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;


           string sel = ConfigurationManager.AppSettings.Get(tag);
           string SelectQuery = sel;//  "SELECT TOP 3  * FROM tblEmployee";
           List<DataFB> list = new List<DataFB>();
           using (SqlConnection con = new SqlConnection(cs))
           {
               SqlCommand cmd = new SqlCommand(SelectQuery, con);
               cmd.CommandType = System.Data.CommandType.Text;
               con.Open();
               SqlDataReader rdr = cmd.ExecuteReader();
               while (rdr.Read())
               {
                   DataFB row = new DataFB(ref rdr);
                   list.Add(row);
               }
           }
           return list;
       }*/
    //-----------------------------------------------------------


    /*    [WebMethod]
        public List<DataFB> GetDataP(string[] arg)
        {
            string tag = arg[0];
            string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
            string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
            string sel = ConfigurationManager.AppSettings.Get(tag);
            string SelectQuery = sel;//  "SELECT TOP 3  * FROM tblEmployee";
            List<DataFB> list = new List<DataFB>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand(SelectQuery, con);
                //cmd.CommandType = System.Data.CommandType.Text;

                cmd.Parameters.Add("@id", SqlDbType.VarChar, 30).Value = arg[1];
                //cmd.Parameters["@id"].Value = "20";

                for (int i = 1; i < arg.Length; i++)
                {
                    cmd.Parameters.Add("@PARAM_" + i.ToString().PadLeft(2, '0'), SqlDbType.VarChar, 100).Value = arg[i];
                }
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    DataFB row = new DataFB(ref rdr);
                    list.Add(row);
                }
            }
            return list;
        }
    */

    [WebMethod]
    public List<DataList> GetData(List<Data> listdata, string qryTag)
    {
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + qryTag);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
        string sel = ConfigurationManager.AppSettings.Get(qryTag);
        string SelectQuery = sel;

        List<DataList> dlList = new List<DataList>();

        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand(SelectQuery, con);

            for (int i = 0; i < listdata.Count; i++)
            {
                string key = "@" + listdata[i]._key.Trim();
                object val = listdata[i]._val;

                if (SelectQuery.Contains(key + " ")) cmd.Parameters.AddWithValue(key, val);
            }

            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                dlList.Add(new DataList(ref rdr));
            }
        }
         return dlList;
    }
    //----------------------------------------------------------------------------------
   
    private SqlCommand GetCmd(ref string query, ref List<Data> listparam)
    {
        SqlCommand cmd = new SqlCommand(query);
        for (int i = 0; i < listparam.Count; i++)
        {
            string key = "@" + listparam[i]._key.Trim();
            object val = listparam[i]._val;

            if (query.Contains(key + " "))
                cmd.Parameters.AddWithValue(key, val);
        }
        return cmd;
    }
    //----------------------------------------------------------------------------------




}
