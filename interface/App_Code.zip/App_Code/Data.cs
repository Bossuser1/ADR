﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Description résumée de Data
/// </summary>
public class Data
{
    public string _key { get; set; }
    public object _val { get; set; }

    public Data()
    { }
    public Data (string key_in, object val_in)
    {
        _key = key_in;
        _val = val_in;
    }
}