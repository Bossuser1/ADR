﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Description résumée de WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// Pour autoriser l'appel de ce service Web depuis un script à l'aide d'ASP.NET AJAX, supprimez les marques de commentaire de la ligne suivante. 
 [System.Web.Script.Services.ScriptService]
public class EmployeeService : System.Web.Services.WebService
{
 

    public EmployeeService()
    {}

    [WebMethod]
    public Employee GetEmployeeByID(int id)
    {
        Employee em = new Employee();
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblEmployee WHERE Id =@Id", con);
            //SqlCommand cmd = new SqlCommand("SELECT * FROM tblEmployee ", con);
            cmd.CommandType = System.Data.CommandType.Text;
            SqlParameter par = new SqlParameter();
            par.ParameterName = "@Id";
            par.Value = id;
            cmd.Parameters.Add(par);
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                em.ID = Convert.ToInt32(rdr["ID"]);
                em.Name = Convert.ToString(rdr["Name"]);
                em.Gender = Convert.ToString(rdr["Gender"]);
                em.Salary = Convert.ToDouble(rdr["Salary"]);
                em.Country = Convert.ToString(rdr["Country"]);
            }
        }
      return em;
    }


    [WebMethod]
    public TabInfo GetTabInfoByName(string tableName)
    {
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + tableName);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
        TabInfo tab = new TabInfo(tableName, cs);
        return tab;
    }
    //---------------------------------------------
    [WebMethod]
    public List<Employee> GetListEmployee()
    {
        List<Employee> list = new List<Employee>();
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
    
        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand("SELECT TOP 2  * FROM tblEmployee ", con);
            cmd.CommandType = System.Data.CommandType.Text;
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                Employee em = new Employee();
                em.ID = Convert.ToInt32(rdr["ID"]);
                em.Name = Convert.ToString(rdr["Name"]);
                em.Gender = Convert.ToString(rdr["Gender"]);
                em.Salary = Convert.ToDouble(rdr["Salary"]);
                list.Add(em);
            }
        }
        return list;
    }

    //-----------------------------------------------------------

    [WebMethod]
    public List<DataFB> GetData(string tag )
    {
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;


        string sel = ConfigurationManager.AppSettings.Get(tag);
        string SelectQuery = sel;//  "SELECT TOP 3  * FROM tblEmployee";
        List<DataFB> list = new List<DataFB>();
        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand(SelectQuery, con);
            cmd.CommandType = System.Data.CommandType.Text;
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                DataFB row = new DataFB(ref rdr);
                list.Add(row);
            }
        }
        return list;
    }
    //-----------------------------------------------------------

    //-----------------------------------------------------------

    [WebMethod]
    //public List<DataFB> GetDataP(string tag, Data string[] arg )
    public List<DataFB> GetDataP( string[] arg)
    { 
        
        string tag = arg[0];
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
        string sel =  ConfigurationManager.AppSettings.Get(tag);
        string SelectQuery = sel;//  "SELECT TOP 3  * FROM tblEmployee";
        List<DataFB> list = new List<DataFB>();
        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand(SelectQuery, con);
            //cmd.CommandType = System.Data.CommandType.Text;

            cmd.Parameters.Add("@id", SqlDbType.VarChar, 30).Value = arg[1];
            //cmd.Parameters["@id"].Value = "20";

            for (int i = 1; i < arg.Length; i++)
            {
                cmd.Parameters.Add("@PARAM_" + i.ToString().PadLeft(2, '0'), SqlDbType.VarChar, 100).Value = arg[i];
            }
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                DataFB row = new DataFB(ref rdr);
                list.Add(row);
            }
        }
        return list;
    }
    //-----------------------------------------------------------

    [WebMethod]
    public int ExecQuery(string tagQuery, List<Data> listparam)
    {
        string tag = tagQuery;
        foreach (Data p in listparam)
        {
            string key = p._key;
            object val = p._val;
            Console.WriteLine(p);
        }

        int result = -1;

        /*
                string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
                string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
                string qry = ConfigurationManager.AppSettings.Get(tag); ;

                List<DataFB> list = new List<DataFB>();
        
                using (SqlConnection con = new SqlConnection(cs))
                {
                    SqlCommand cmd = new SqlCommand(qry, con);
                    cmd.Parameters.Add("@id", SqlDbType.VarChar, 30).Value = listparam[1];

                    for (int i = 1; i < listparam.Count; i++)
                    {
                        cmd.Parameters.Add("@PARAM_" + i.ToString().PadLeft(2, '0'), SqlDbType.VarChar, 100).Value = list[i];
                    }


                    SqlTransaction transc_ = null;//TRANSACTION  
                    try
                    {
                        con.Open();

                         //START TRANSACTION - Critical Zone write to database TRANSACTION


                        transc_ = con.BeginTransaction(Math.Round(DateTime.UtcNow.Subtract(new DateTime(2014, 1, 1, 0, 0, 0)).TotalSeconds, 0).ToString());//TRANSACTION
                        if (transc_ == null) { throw new Exception("transc_ == null;"); } //TRANSACTION
                        cmd.Transaction = transc_; //TRANSACTION
                        result = cmd.ExecuteNonQuery();
                        transc_.Commit();//TRANSACTION


                         //END TRANSACTION - Critical Zone write to database TRANSACTION

                        cmd.Dispose();
                    }
                    catch (Exception err)
                    {
                        //Utils.ExcepMsg.TrcExcep("DBA.ExecuteQuery: " + err.Message.ToUpper() + " query:" + query);
                        try
                        {
                            transc_.Rollback(); //TRANSACTION
                        }
                        catch (Exception err2)
                        {
                            //Utils.ExcepMsg.TrcExcep("Rollback Exception Type: {0}; " + err2.GetType() + " query: " + query);
                            //Utils.ExcepMsg.TrcExcep("Message: {0}; " + err2.Message + " query: " + query);
                        }
                    }
        }
        */
        return result;
    }

    //-----------------------------------------------------------
    [WebMethod]
    public int ExecQueryByParam(string tagQuery, List<Data> listparam)
    {
        string tag = tagQuery;
        //foreach (Data p in listparam)
        //{
        //    string key = p._key;
        //    object val = p._val;
        //    //Console.WriteLine(p);
        //}

        int result = -1;
        string tagcs = ConfigurationManager.AppSettings.Get("cs" + tag);
        string cs = ConfigurationManager.ConnectionStrings[tagcs].ConnectionString;
        string qry = ConfigurationManager.AppSettings.Get(tag);

        //List<DataFB> list = new List<DataFB>();

        using (SqlConnection con = new SqlConnection(cs))
        {
            SqlCommand cmd = new SqlCommand(qry, con);

            for (int i = 0; i < listparam.Count; i++)
            {
                string key = listparam[i]._key.Trim();
                object val = listparam[i]._val;
                cmd.Parameters.AddWithValue("@"+ key, val) ;
            }
            //cmd.Parameters.AddWithValue("@Name", "45");


            SqlTransaction transc_ = null;//TRANSACTION  
            try
            {
                con.Open();
                //START TRANSACTION - Critical Zone write to database TRANSACTION


                transc_ = con.BeginTransaction(Math.Round(DateTime.UtcNow.Subtract(new DateTime(2014, 1, 1, 0, 0, 0)).TotalSeconds, 0).ToString());//TRANSACTION
                if (transc_ == null) { throw new Exception("transc_ == null;"); } //TRANSACTION
                cmd.Transaction = transc_; //TRANSACTION
                result = cmd.ExecuteNonQuery();
                transc_.Commit();//TRANSACTION

                //END TRANSACTION - Critical Zone write to database TRANSACTION
                cmd.Dispose();
            }
            catch (Exception err)
            {
                Utils.ExcepMsg.TrcExcep("DBA.ExecuteQuery: " + err.Message.ToUpper() + " query:" + qry);
                try
                {
                    transc_.Rollback(); //TRANSACTION
                }
                catch (Exception err2)
                {
                    Utils.ExcepMsg.TrcExcep("Rollback Exception Type: {0}; " + err2.GetType() + " query: " + qry);
                    Utils.ExcepMsg.TrcExcep("Message: {0}; " + err2.Message + " query: " + qry);
                }
            }
        }



        return result;
    }
    //-----------------------------------------------------------
}

