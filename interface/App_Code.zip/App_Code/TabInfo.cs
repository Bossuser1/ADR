﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de TableInfo
/// </summary>
public class TabInfo
{
    public string Name;
    //On traite les primarykeys autoincrement comme une colonne autoincrement
    //public Dictionary<string, ColInfo> AutoIncrmnt = new Dictionary<string, ColInfo>();
    //public Dictionary<string, ColInfo> PrimaryKeys = new Dictionary<string, ColInfo>();
    //public Dictionary<string, ColInfo> ColmnNoNULL = new Dictionary<string, ColInfo>();
    //public Dictionary<string, ColInfo> ColmnNormal = new Dictionary<string, ColInfo>();
    public List< ColInfo> Columns = new List<ColInfo>();

    public TabInfo()
    { }
    public TabInfo(string Name_in, string ConStr)
    {
        this.Name = Name_in;
        //this.AutoIncrmnt = this.GetColumns(this.Name, ConStr, "AutoIncrmnt");
        //this.PrimaryKeys = this.GetColumns(this.Name, ConStr, "PrimaryKeys");
        //this.ColmnNoNULL = this.GetColumns(this.Name, ConStr, "ColmnNoNULL");
        //this.ColmnNormal = this.GetColumns(this.Name, ConStr, "ColmnNormal");
        this.Columns = this.GetColumns(this.Name, ConStr, "Columns");

        if (
            Columns.Where(p => p.IS_PRIMARY_KEY == true).Count() == 0
            &&
            Columns.Where(p => p.IS_AUTO_INCRIMENT == true).Count() == 0
            )
        {
            Utils.ExcepMsg.TrcMsgToFile("Vous ne pouvez pas utiliser cet objet car la table " + this.Name + " n'a pas de clé primaire. ", @"D:\test.log");
        }
        
    }

    public SqlCommand Insert(ref List<Data> listparam)
    {
        string insertColName = "";
        string insertColVal = "";
        string insert = "";//INSERT INTO  [" + this.Name + "]"  + "(" + insertColName + ") VALUES " + "(" + insertColVal + ")";

        for (int i = 0; i < this.Columns.Count(); i++)
        {
            /*
             On n'insert pas les autoincrement, on ne insert pas les chmps nullable non fourni!
             */
            string colName = this.Columns.ElementAt(i).COLUMN_NAME;
            if (
                !this.Columns.ElementAt(i).IS_AUTO_INCRIMENT
                &&
                listparam.Where(p => p._key == colName).Count() > 0 /* les chmps nullable fourni*/
                )
            {
                insertColName = insertColName + " [" + colName + "] ,";
                insertColVal = insertColVal + " @" + colName + " ,";
            }
        }
        if (insertColName.EndsWith(",")) insertColName = insertColName.Remove(insertColName.Length-1 , 1);
        if (insertColVal.EndsWith(",")) insertColVal = insertColVal.Remove(insertColVal.Length-1  , 1);
        insert = "INSERT INTO  [" + this.Name + "]" + "( " + insertColName + " ) VALUES " + "( " + insertColVal + " )";

        return this.GetCmd(ref insert, ref  listparam);
    }


    public SqlCommand Update(ref List<Data> listparam)
    {
        string updateColmnValeur = "";
        string updateWhereClause = "";
        string update = "";// "UPDATE ["+this.Name+"] SET "+ updateColmnValeur+" WHERE "+ updateWhereClause;

        for (int i = 0; i < this.Columns.Count(); i++)
        {
            /*
             On update pas les autoincrement et les primarykeys
             */
            string colName = this.Columns.ElementAt(i).COLUMN_NAME;
            if (
                !this.Columns.ElementAt(i).IS_AUTO_INCRIMENT
                &&
                !this.Columns.ElementAt(i).IS_PRIMARY_KEY
                &&
                listparam.Where(p => p._key == colName).Count() > 0
                )
            {
                updateColmnValeur = updateColmnValeur + " [" + colName + "] = @" + colName + " ,";
            }

            if (
                (this.Columns.ElementAt(i).IS_AUTO_INCRIMENT
                ||
                this.Columns.ElementAt(i).IS_PRIMARY_KEY)
                &&
                listparam.Where(p => p._key == colName).Count() > 0
                )
            {
                updateWhereClause = updateWhereClause + " [" + colName + "] = @" + colName + " AND";
            }
        }
        if (updateColmnValeur.EndsWith(",")) updateColmnValeur = updateColmnValeur.Remove(updateColmnValeur.Length-1  , 1);
        if (updateWhereClause.EndsWith(" AND")) updateWhereClause = updateWhereClause.Remove(updateWhereClause.Length - 3, 3);
        update = "UPDATE [" + this.Name + "] SET " + updateColmnValeur + " WHERE " + updateWhereClause;
        return this.GetCmd(ref update, ref listparam);
    }

    public SqlCommand Delete(ref List<Data> listparam)
    {
        string deleteWhereClause = "";
        string delete = "";// "DELETE ["+this.Name+"] WHERE "+  deleteWhereClause;

        for (int i = 0; i < this.Columns.Count(); i++)
        {
            string colName = this.Columns.ElementAt(i).COLUMN_NAME;

            if (
                (this.Columns.ElementAt(i).IS_AUTO_INCRIMENT
                ||
                this.Columns.ElementAt(i).IS_PRIMARY_KEY)
                &&
                listparam.Where(p => p._key == colName).Count() > 0
                )
            {
                deleteWhereClause = deleteWhereClause + " [" + colName + "] = @" + colName + " AND";
            }
        }
        if (deleteWhereClause.EndsWith(" AND")) deleteWhereClause = deleteWhereClause.Remove(deleteWhereClause.Length - 3, 3);
        delete = "DELETE [" + this.Name + "] WHERE " + deleteWhereClause;
        return this.GetCmd(ref delete, ref listparam);
    }


    //---------------------------------------------------------
    private List< ColInfo> GetColumns(string tableName, string ConStr, string typCol)
    {
        string qGetColumnName = @" SELECT 
                                        COLUMN_NAME
                                        , CASE WHEN IS_NULLABLE='NO' THEN 0 ELSE 1 END AS 'IS_NULLABLE'
                                        , DATA_TYPE
                                        , ISNULL(CHARACTER_MAXIMUM_LENGTH, -1) AS 'CHARACTER_MAXIMUM_LENGTH'
                                        
                                        , ( SELECT COUNT(*)
                                        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                                        WHERE 
                                        OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + QUOTENAME(CONSTRAINT_NAME)), 'IsPrimaryKey') = 1
                                        AND INFORMATION_SCHEMA.KEY_COLUMN_USAGE.TABLE_NAME = 'tableName' 
                                        AND INFORMATION_SCHEMA.KEY_COLUMN_USAGE.TABLE_SCHEMA = 'dbo' 
                                        AND INFORMATION_SCHEMA.KEY_COLUMN_USAGE.COLUMN_NAME =INFORMATION_SCHEMA.COLUMNS.COLUMN_NAME ) 
                                        AS 'IS_PRIMARY_KEY'

                                      , ISNULL( ( SELECT  sep.value from SYS.TABLES st
                                        inner join SYS.COLUMNS sc on st.object_id = sc.object_id
                                        left join SYS.extended_properties sep on st.object_id = sep.major_id
                                                                             and sc.column_id = sep.minor_id
                                                                             and sep.name = 'MS_Description'
                                        WHERE st.name = 'tableName' and sc.name = INFORMATION_SCHEMA.COLUMNS.COLUMN_NAME), '') 
                                        AS 'MS_DESCRIPTION'
                                        
                                        , ISNULL(COLUMNPROPERTY(object_id(TABLE_SCHEMA+'.'+'tableName'), COLUMN_NAME, 'IsIdentity'),0 ) AS 'AUTO_INCRIMENT'
                                        FROM  INFORMATION_SCHEMA.COLUMNS
                                        WHERE INFORMATION_SCHEMA.COLUMNS.TABLE_NAME = 'tableName'   ".Replace("tableName", tableName);

        List< ColInfo> Columns = new List<ColInfo>();

        using (SqlConnection sqlConn = new SqlConnection(ConStr))
        using (SqlCommand cmd = new SqlCommand(qGetColumnName, sqlConn))
        {
            string colName = "";
            bool isNullable = false;
            string datTyp = "";
            int carMax = -1;
            bool is_pri_key = false;
            bool is_auto_inc = false;
            string ms_descrip = "";

            sqlConn.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            if (dt.Rows.Count == 0) return Columns;
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    colName = Convert.ToString(dt.Rows[i]["COLUMN_NAME"]);
                    isNullable = Convert.ToBoolean(dt.Rows[i]["IS_NULLABLE"]);
                    datTyp = Convert.ToString(dt.Rows[i]["DATA_TYPE"]);
                    carMax = Convert.ToInt32(dt.Rows[i]["CHARACTER_MAXIMUM_LENGTH"]);
                    is_pri_key = Convert.ToBoolean(dt.Rows[i]["IS_PRIMARY_KEY"]);
                    is_auto_inc = Convert.ToBoolean(dt.Rows[i]["AUTO_INCRIMENT"]);
                    ms_descrip = Convert.ToString(dt.Rows[i]["MS_DESCRIPTION"]);

                    if (typCol == "Columns") Columns.Add(new ColInfo(colName, isNullable, datTyp, carMax, is_pri_key, is_auto_inc, ms_descrip));

                    //if (typCol == "AutoIncrmnt" && (is_auto_inc))
                    //    Columns.Add(colName, new ColInfo(colName, isNullable, datTyp, carMax, is_pri_key, is_auto_inc, ms_descrip));

                    //if (typCol == "PrimaryKeys" && (is_pri_key || !is_auto_inc))
                    //    Columns.Add(colName, new ColInfo(colName, isNullable, datTyp, carMax, is_pri_key, is_auto_inc, ms_descrip));

                    //if (typCol == "ColmnNoNULL" && (!is_pri_key && !is_auto_inc) && !isNullable)
                    //    Columns.Add(colName, new ColInfo(colName, isNullable, datTyp, carMax, is_pri_key, is_auto_inc, ms_descrip));

                    //if (typCol == "ColmnNormal" && (!is_pri_key && !is_auto_inc) && isNullable)
                    //    Columns.Add(colName, new ColInfo(colName, isNullable, datTyp, carMax, is_pri_key, is_auto_inc, ms_descrip));
                }
                return Columns;
            }
        }
        
    }

    //--------------------------------------------
    private SqlCommand GetCmd(ref string query, ref List<Data> listparam)
    {
        SqlCommand cmd = new SqlCommand(query);
        for (int i = 0; i < listparam.Count; i++)
        {
            string key = "@" + listparam[i]._key.Trim();
            object val = listparam[i]._val;

            if (query.Contains(key+" "))
            cmd.Parameters.AddWithValue(key, val);
        }
        return cmd;
    }

}