﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Description résumée de DBA
/// </summary>
public class DBA
{
    static Dictionary<string, TabInfo> DicoTable = new Dictionary<string, TabInfo>();

    //-----------------------------------------------
    //static public DataTable GetValues(string SelectQuery, string SqlConStrConfig = "SqlConStrConfig")
    //{
    //    using (SqlConnection sqlConn = new SqlConnection(Utils.XML.GetValByTag(SqlConStrConfig)))
    //    using (SqlCommand cmd = new SqlCommand(SelectQuery, sqlConn))
    //    {
    //        sqlConn.Open();
    //        DataTable dt = new DataTable();
    //        dt.Load(cmd.ExecuteReader());
    //        return dt;
    //    }
    //}

    //---------------------------------------------------------
    //static public bool IsNullable(string tableName, string colomnName, string ConStr)
    //{
    //    string query = @"SELECT CASE WHEN IS_NULLABLE='NO' THEN 0 ELSE 1 END AS 'IS_NULLABLE'
    //                        FROM  INFORMATION_SCHEMA.COLUMNS
    //                        WHERE TABLE_NAME = '" + tableName + "' AND COLUMN_NAME = '" + colomnName + "'";
    //    using (SqlConnection sqlConn = new SqlConnection(Utils.XML.GetValByTag(ConStr)))
    //    using (SqlCommand cmd = new SqlCommand(query, sqlConn))
    //    {
    //        sqlConn.Open();
    //        DataTable dt = new DataTable();
    //        dt.Load(cmd.ExecuteReader());
    //        if (dt.Rows.Count == 0) return false;
    //        else
    //        {
    //            return Convert.ToBoolean(dt.Rows[0][0]);
    //        }
    //    }
    //}



    //--------------------------------------------------------------
    static public TabInfo GetTable(string tableName, string ConStr)
    {
        if (!DicoTable.ContainsKey(tableName))
        {
            //TabInfo tab = new TabInfo(tableName, ConStr);
            //DicoTable.Add(tableName, tab);
        }

        return DicoTable[tableName];
    }

}