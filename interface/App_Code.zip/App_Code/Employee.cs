﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Description résumée de Class1
/// </summary>
public class Employee
{
    public int ID { get; set; }
    public string Name { get; set; }
    public string Gender { get; set; }
    public double Salary { get; set; }
    public string Country { get; set; }



    [WebMethod]
    public static Employee GetEmployee()
    {
        Employee em = new  Employee();
        return em;
    }

}