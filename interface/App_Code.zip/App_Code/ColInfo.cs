﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de ColInfo
/// </summary>
public class ColInfo
{
    public string COLUMN_NAME;
    public bool IS_NULLABLE;
    public bool IS_AUTO_INCRIMENT;
    public string DATA_TYPE;
    public int CHARACTER_MAXIMUM_LENGTH;
    public bool IS_PRIMARY_KEY;
    public string MS_DESCRIPTION;

    public ColInfo()
    { }

    public ColInfo(string colName, bool isNullable, string datTyp, int car_max_leng, bool is_pri_key, bool is_auto_inc, string MS_Description_in)
    {
        this.COLUMN_NAME = colName;
        this.IS_NULLABLE = isNullable;
        this.DATA_TYPE = datTyp;
        this.CHARACTER_MAXIMUM_LENGTH = car_max_leng;
        this.IS_PRIMARY_KEY = is_pri_key;
        this.IS_AUTO_INCRIMENT = is_auto_inc;
        this.MS_DESCRIPTION = MS_Description_in;

    }
}