﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de DataList
/// </summary>
public class DataList
{
    public List<Data> List { get => list; set => list = value; }
    private List<Data> list;
 

    public DataList()
    { }

    public DataList(ref SqlDataReader rdr)
    {
        this.list = new List<Data>();

        for (int i = 0; i < rdr.FieldCount; i++)
        {
            list.Add(new Data(Convert.ToString(rdr.GetName(i)), rdr.GetValue(i)));
        }
    }
}