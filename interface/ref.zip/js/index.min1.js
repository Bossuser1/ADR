console.log("JavaScript is amazing!");
//# sourceMappingURL=index.min.js.map
