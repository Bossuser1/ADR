/*https://cssreference.io/flexbox/   */
/*-----   todo 
gestion des cliques
-----*/
$(function() {
   $('a.link').click(function() {
       $('a.link').removeClass('active');
       $(this).addClass('active');
   });
});

/*
$("p:after" ).click(function() {
  var color = $( this ).css( "visibility" );
  $("#result" ).html("That div is <span style='color:" +
    color + ";'>" + color + "</span>." );
});
*/
/*
$(document).ready(function(){
    $("p:after").click(function(){
        $("p:after").attr("visibility","hidden");
    });
});


$("p:after" )
  .focusout(function() {
    $("" ).css('display',:none;);
  });
*/
$("p").css("display", "block");