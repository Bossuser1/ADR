/*https://cssreference.io/flexbox/   */
/*-----   todo 
gestion des cliques
-----*/
$(function() {
   $('a.link').click(function() {
       $('a.link').removeClass('active');
       $(this).addClass('active');
   });
});


$("p").css("display", "block");


/*  for slidebar */

var menuToggle = function(el){
  el.toggleClass('active');
  el.children('.inside').slideToggle(200);
}

$('.sidebar .section .item p').on('click', function(){
  menuToggle($(this).parent());
  menuToggle($(this).parent().siblings('.item.active'));
});


/*------try to call page by click on appl  --*/
/*
$( "#Roulements" ).click(function() {
  alert( "Handler for .click() called." );
});
*/
$("p").click(function(){
        $("#Roulement").load("demo_test.txt", function(responseTxt, statusTxt, xhr){
            if(statusTxt == "success")
                alert("External content loaded successfully!");
            if(statusTxt == "error")
                alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
});
