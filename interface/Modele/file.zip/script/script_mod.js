var data1;

var data1=1;