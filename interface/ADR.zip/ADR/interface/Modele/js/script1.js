var data1;
var data1=1;

/*var height = document.getElementById('containername').style.height;
var width = document.getElementById('containername').style.width;
*/