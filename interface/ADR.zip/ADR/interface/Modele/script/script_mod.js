var data1;

var data1=1;


document.getElementById("mySelect");

var height = document.getElementById('containername').style.height;
var width = document.getElementById('containername').style.width;



alert(height);
