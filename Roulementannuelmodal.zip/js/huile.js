var DG_Definition
            = [
                {"ColName": "IdHuiles", "Width": 50, "Visible": true, "ColumnHeader": "IdHuiles" },
                {"ColName": "Nom", "Width": 150, "Visible": true, "ColumnHeader": "Nom" },
                {"ColName": "CodeAdr", "Width": 200, "Visible": true, "ColumnHeader": "CodeAdr" },
        { "ColName": "Fabricant", "Width": 200, "Visible": true, "ColumnHeader": "Fabricant" },
    ];
var DG_QUERY_TAG = "GetHuiles";
var DG_TABLE_NAME = "Huiles";